/*
 * Copyright (c) 2025 lax1dude. All Rights Reserved.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * 
 */

package net.lax1dude.eaglercraft.backend.server.api.skins;

import java.util.UUID;
import java.util.function.Consumer;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public interface IProfileResolver {

	void resolveVanillaUUIDFromUsername(@Nonnull String username, @Nonnull Consumer<UUID> callback);

	void resolveVanillaTexturesFromUUID(@Nonnull UUID uuid, @Nonnull Consumer<TexturesProperty> callback);

	default void resolveVanillaTexturesFromUsername(@Nonnull String username,
			@Nonnull Consumer<TexturesProperty> callback) {
		resolveVanillaUUIDFromUsername(username, (uuid) -> {
			if (uuid != null) {
				resolveVanillaTexturesFromUUID(uuid, callback);
			} else {
				callback.accept(null);
			}
		});
	}

	@Nullable
	TexturesResult decodeVanillaTextures(@Nonnull String propertyValue);

	@Nullable
	default TexturesResult decodeVanillaTextures(@Nonnull TexturesProperty property) {
		return decodeVanillaTextures(property.getValue());
	}

}
